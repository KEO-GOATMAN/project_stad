const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:3000/api';

export async function login(username: string, password: string) {
  const response = await fetch(`${API_URL}/login`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ username, password }),
  });

  if (!response.ok) {
    throw new Error('Invalid credentials');
  }

  return response.json();
}

export async function sendNotification(housing: any, taskSummaries: any[], cleanerEmail: string) {
  const token = localStorage.getItem('token');
  
  const response = await fetch(`${API_URL}/send-notification`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`,
    },
    body: JSON.stringify({ housing, taskSummaries, cleanerEmail }),
  });

  if (!response.ok) {
    throw new Error('Failed to send notification');
  }

  return response.json();
}