export const shouldShowWarning = (rating: number): boolean => {
  return rating >= 1 && rating <= 3;
};

export const generateRatingComment = (rating: number, existingComment: string = ''): string => {
  if (!shouldShowWarning(rating)) return existingComment;
  
  const warningPrefix = '⚠️ Requires attention! Please check and verify. ';
  
  if (!existingComment) {
    return warningPrefix;
  }
  
  return existingComment.startsWith(warningPrefix) 
    ? existingComment 
    : `${warningPrefix}${existingComment}`;
};