export const generateId = () => Math.random().toString(36).substr(2, 9);

export const DEFAULT_TASKS = [
  { 
    id: '1', 
    text: 'Clean floor', 
    rating: 0,
    details: {}
  },
  { 
    id: '2', 
    text: 'Check walls for cleanliness', 
    rating: 0,
    details: {}
  },
  { 
    id: '3', 
    text: 'Empty trash bins', 
    rating: 0,
    details: {}
  },
];