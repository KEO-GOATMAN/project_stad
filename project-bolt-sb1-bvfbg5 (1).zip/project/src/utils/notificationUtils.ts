import { Task } from '../types/task';
import { Housing } from '../types/housing';

export interface TaskSummary {
  taskText: string;
  rating: number;
  comment: string;
  imageUrl?: string;
}

export function generateTaskSummary(tasks: Task[]): TaskSummary[] {
  return tasks
    .filter(task => task.rating >= 1 && task.rating <= 3)
    .map(task => ({
      taskText: task.text,
      rating: task.rating,
      comment: task.details.comment || '',
      imageUrl: task.details.imageUrl
    }));
}

export function generateEmailContent(housing: Housing, taskSummaries: TaskSummary[]): string {
  if (taskSummaries.length === 0) return '';

  const dateStr = new Date().toLocaleDateString('sv-SE');
  
  let emailContent = `
Städrapport - ${housing.name} (${dateStr})
------------------------------------------

Brf: ${housing.brf}
Adress: ${housing.address}
Städare: ${housing.cleanerName}

Följande punkter kräver åtgärd:

`;

  taskSummaries.forEach(summary => {
    const stars = '★'.repeat(summary.rating) + '☆'.repeat(5 - summary.rating);
    emailContent += `
• ${summary.taskText}
  Betyg: ${stars}
  ${summary.comment ? `Kommentar: ${summary.comment}` : ''}
  ${summary.imageUrl ? `Bild: ${summary.imageUrl}` : ''}
`;
  });

  emailContent += `
Vänligen åtgärda dessa punkter innan nästa städtillfälle.

Med vänliga hälsningar,
Optimal Trappstädning
`;

  return emailContent;
}