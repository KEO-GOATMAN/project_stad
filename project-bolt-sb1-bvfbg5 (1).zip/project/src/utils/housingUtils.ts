import { Housing } from '../types/housing';

export const MOCK_HOUSING_LIST: Housing[] = [
  {
    id: '1',
    name: 'Solbacken',
    brf: 'Brf Solbacken',
    address: 'Solbackavägen 1, Stockholm',
    code: '1234',
    cleaningRoom: 'Källaren, rum 12',
    cleanerName: 'Anna Andersson',
    cleaningDay: 'Måndag'
  },
  {
    id: '2',
    name: 'Sjöutsikten',
    brf: 'Brf Sjöutsikten',
    address: 'Sjögatan 15, Stockholm',
    code: '5678',
    cleaningRoom: 'Våning 1, rum 3',
    cleanerName: 'Erik Eriksson',
    cleaningDay: 'Tisdag'
  },
  {
    id: '3',
    name: 'Parkvy',
    brf: 'Brf Parkvy',
    address: 'Parkgatan 8, Stockholm',
    code: '9012',
    cleaningRoom: 'Bottenvåning, rum 5',
    cleanerName: 'Maria Nilsson',
    cleaningDay: 'Onsdag'
  }
];