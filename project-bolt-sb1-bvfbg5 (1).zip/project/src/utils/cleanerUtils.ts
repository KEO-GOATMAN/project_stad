import { Cleaner } from '../types/cleaner';

export const MOCK_CLEANERS: Cleaner[] = [];

export const generateCleanerId = () => Math.random().toString(36).substr(2, 9);

export const findCleanerByHousing = (cleaners: Cleaner[], housingId: string): Cleaner | undefined => {
  return cleaners.find(cleaner => cleaner.assignedBrfs.includes(housingId));
};