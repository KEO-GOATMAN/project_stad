import React, { useState, useEffect } from 'react';
import { ChevronDown, ChevronUp, Image as ImageIcon, MessageSquare } from 'lucide-react';
import { TaskDetail } from '../types/task';
import { generateRatingComment } from '../utils/ratingUtils';

interface TaskDetailsProps {
  isOpen: boolean;
  details: TaskDetail;
  onUpdate: (details: TaskDetail) => void;
  onToggle: () => void;
  rating: number;
}

export function TaskDetails({ isOpen, details = {}, onUpdate, onToggle, rating }: TaskDetailsProps) {
  const [comment, setComment] = useState('');
  const [imageUrl, setImageUrl] = useState('');

  useEffect(() => {
    setComment(details.comment || '');
    setImageUrl(details.imageUrl || '');
  }, [details]);

  useEffect(() => {
    const updatedComment = generateRatingComment(rating, comment);
    if (updatedComment !== comment) {
      setComment(updatedComment);
      onUpdate({ ...details, comment: updatedComment });
    }
  }, [rating]);

  const handleCommentChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const newComment = e.target.value;
    setComment(newComment);
    onUpdate({ ...details, comment: newComment });
  };

  const handleImageUrlChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newImageUrl = e.target.value;
    setImageUrl(newImageUrl);
    onUpdate({ ...details, imageUrl: newImageUrl });
  };

  return (
    <div className="w-full">
      <button
        onClick={onToggle}
        className="w-full flex items-center justify-center py-2 text-gray-500 hover:text-gray-700"
      >
        {isOpen ? <ChevronUp size={20} /> : <ChevronDown size={20} />}
      </button>
      
      {isOpen && (
        <div className="mt-2 space-y-4 p-4 bg-gray-50 rounded-lg">
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-gray-700">
              <MessageSquare size={16} />
              <label htmlFor="comment" className="text-sm font-medium">
                Comment
              </label>
            </div>
            <textarea
              id="comment"
              value={comment}
              onChange={handleCommentChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              rows={3}
              placeholder="Add a comment..."
            />
          </div>

          <div className="space-y-2">
            <div className="flex items-center gap-2 text-gray-700">
              <ImageIcon size={16} />
              <label htmlFor="imageUrl" className="text-sm font-medium">
                Image URL
              </label>
            </div>
            <input
              type="url"
              id="imageUrl"
              value={imageUrl}
              onChange={handleImageUrlChange}
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Enter image URL..."
            />
            {imageUrl && (
              <div className="mt-2">
                <img
                  src={imageUrl}
                  alt="Task documentation"
                  className="max-w-full h-auto rounded-lg"
                  onError={(e) => {
                    (e.target as HTMLImageElement).style.display = 'none';
                  }}
                />
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}