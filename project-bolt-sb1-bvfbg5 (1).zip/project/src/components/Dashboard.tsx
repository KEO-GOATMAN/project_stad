import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Task, TaskDetail } from '../types/task';
import { TaskItem } from './TaskItem';
import { AddTaskForm } from './AddTaskForm';
import { Header } from './Header';
import { EditHousingModal } from './EditHousingModal';
import { NotifyCleanerModal } from './NotifyCleanerModal';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { useDefaultTasks } from '../hooks/useDefaultTasks';
import { generateId } from '../utils/taskUtils';
import { MOCK_HOUSING_LIST } from '../utils/housingUtils';
import { ArrowLeft, Building2, MapPin, Key, DoorClosed, User, Calendar, Pencil, Mail } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { Housing } from '../types/housing';

export function Dashboard() {
  const { housingId } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const { getInitialTasks } = useDefaultTasks();
  const [isEditModalOpen, setIsEditModalOpen] = useState(false);
  const [isNotifyModalOpen, setIsNotifyModalOpen] = useState(false);
  const [housing, setHousing] = useLocalStorage<Housing>(
    `housing-${housingId}`,
    MOCK_HOUSING_LIST.find(h => h.id === housingId) || MOCK_HOUSING_LIST[0]
  );

  const [tasks, setTasks] = useLocalStorage<Task[]>(
    `cleaning-tasks-${housingId}`,
    getInitialTasks()
  );

  React.useEffect(() => {
    if (!housing) {
      navigate('/housing');
    }
  }, [housing, navigate]);

  const addTask = (text: string) => {
    setTasks([...tasks, { id: generateId(), text, rating: 0, details: {} }]);
  };

  const rateTask = (id: string, rating: number) => {
    setTasks(tasks.map(task => 
      task.id === id ? { ...task, rating } : task
    ));
  };

  const deleteTask = (id: string) => {
    setTasks(tasks.filter(task => task.id !== id));
  };

  const updateTaskDetails = (id: string, details: TaskDetail) => {
    setTasks(tasks.map(task =>
      task.id === id ? { ...task, details } : task
    ));
  };

  const handleHousingUpdate = (updatedHousing: Housing) => {
    setHousing(updatedHousing);
  };

  const resetTasks = () => {
    setTasks(getInitialTasks());
  };

  if (!housing) {
    return null;
  }

  const hasLowRatedTasks = tasks.some(task => task.rating >= 1 && task.rating <= 3);

  return (
    <div className="min-h-screen bg-gray-100">
      <Header />
      <div className="max-w-3xl mx-auto p-6">
        <div className="bg-white rounded-lg shadow-lg p-6">
          <div className="flex justify-between items-center mb-4">
            <div className="flex gap-2">
              <button
                onClick={() => navigate('/housing')}
                className="p-2 text-gray-600 hover:text-gray-800 hover:bg-gray-100 rounded-full transition-colors"
                title="Return to Selection"
              >
                <ArrowLeft size={24} />
              </button>
              {user?.role === 'admin' && (
                <button
                  onClick={() => setIsEditModalOpen(true)}
                  className="p-2 text-gray-600 hover:text-gray-800 hover:bg-gray-100 rounded-full transition-colors"
                  title="Edit Information"
                >
                  <Pencil size={24} />
                </button>
              )}
            </div>
            {user?.role === 'admin' && hasLowRatedTasks && (
              <button
                onClick={() => setIsNotifyModalOpen(true)}
                className="flex items-center gap-2 px-4 py-2 text-white bg-blue-500 rounded-lg hover:bg-blue-600"
              >
                <Mail size={20} />
                Notify Cleaner
              </button>
            )}
          </div>

          <div className="space-y-4 mb-6">
            <h1 className="text-3xl font-bold text-gray-800">
              {housing.name}
            </h1>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-gray-600">
              <div className="flex items-center gap-2">
                <Building2 size={18} className="text-blue-500" />
                <span>Brf: {housing.brf}</span>
              </div>
              <div className="flex items-center gap-2">
                <MapPin size={18} className="text-blue-500" />
                <span>Adress: {housing.address}</span>
              </div>
              <div className="flex items-center gap-2">
                <Key size={18} className="text-blue-500" />
                <span>Kod: {housing.code}</span>
              </div>
              <div className="flex items-center gap-2">
                <DoorClosed size={18} className="text-blue-500" />
                <span>Städrum: {housing.cleaningRoom}</span>
              </div>
              <div className="flex items-center gap-2">
                <User size={18} className="text-blue-500" />
                <span>Namn på Städare: {housing.cleanerName}</span>
              </div>
              <div className="flex items-center gap-2">
                <Calendar size={18} className="text-blue-500" />
                <span>Veckodag Städ: {housing.cleaningDay}</span>
              </div>
            </div>
          </div>

          <AddTaskForm onAdd={addTask} />

          <div className="space-y-3">
            {tasks.map((task) => (
              <TaskItem
                key={task.id}
                task={task}
                onRate={rateTask}
                onDelete={deleteTask}
                onUpdateDetails={updateTaskDetails}
              />
            ))}
          </div>
        </div>
      </div>

      {isEditModalOpen && (
        <EditHousingModal
          housing={housing}
          onClose={() => setIsEditModalOpen(false)}
          onSave={handleHousingUpdate}
        />
      )}

      {isNotifyModalOpen && (
        <NotifyCleanerModal
          housing={housing}
          tasks={tasks}
          onClose={() => setIsNotifyModalOpen(false)}
          onReset={resetTasks}
        />
      )}
    </div>
  );
}