import React, { useState } from 'react';
import { Mail, X, Send, RefreshCw, Image as ImageIcon } from 'lucide-react';
import { Task } from '../types/task';
import { Housing } from '../types/housing';
import { TaskSummary, generateTaskSummary, generateEmailContent } from '../utils/notificationUtils';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { Cleaner } from '../types/cleaner';
import { findCleanerByHousing } from '../utils/cleanerUtils';

interface NotifyCleanerModalProps {
  housing: Housing;
  tasks: Task[];
  onClose: () => void;
  onReset: () => void;
}

export function NotifyCleanerModal({ housing, tasks, onClose, onReset }: NotifyCleanerModalProps) {
  const [isSending, setIsSending] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [cleaners] = useLocalStorage<Cleaner[]>('cleaners', []);
  
  const taskSummaries = generateTaskSummary(tasks);
  const emailContent = generateEmailContent(housing, taskSummaries);
  const cleaner = findCleanerByHousing(cleaners, housing.id);

  const handleSendAndReset = async () => {
    setIsSending(true);
    try {
      // In a real application, you would send the email here
      await new Promise(resolve => setTimeout(resolve, 1000)); // Simulate API call
      setIsSuccess(true);
      onReset();
      setTimeout(onClose, 2000);
    } catch (error) {
      console.error('Failed to send notification:', error);
    } finally {
      setIsSending(false);
    }
  };

  if (taskSummaries.length === 0) {
    return (
      <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
        <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-2xl mx-4">
          <div className="flex justify-between items-center mb-6">
            <div className="flex items-center gap-3">
              <Mail className="h-6 w-6 text-blue-500" />
              <h2 className="text-2xl font-bold text-gray-800">Notify Cleaner</h2>
            </div>
            <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
              <X size={24} />
            </button>
          </div>
          <p className="text-gray-600 mb-6">
            No tasks require attention. All ratings are satisfactory.
          </p>
          <div className="flex justify-end">
            <button
              onClick={onClose}
              className="px-4 py-2 text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-2xl mx-4">
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center gap-3">
            <Mail className="h-6 w-6 text-blue-500" />
            <h2 className="text-2xl font-bold text-gray-800">Notify Cleaner</h2>
          </div>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700"
            disabled={isSending}
          >
            <X size={24} />
          </button>
        </div>

        <div className="mb-6">
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-lg font-semibold text-gray-800">
              Email Preview
            </h3>
            {cleaner && (
              <p className="text-sm text-gray-600">
                Sending to: {cleaner.email}
              </p>
            )}
          </div>
          <div className="bg-gray-50 p-4 rounded-lg">
            <div className="whitespace-pre-wrap font-mono text-sm mb-4">
              {emailContent}
            </div>
            {taskSummaries.some(task => task.imageUrl) && (
              <div className="border-t border-gray-200 pt-4">
                <h4 className="text-sm font-semibold text-gray-700 mb-2 flex items-center gap-2">
                  <ImageIcon size={16} />
                  Attached Images:
                </h4>
                <div className="grid grid-cols-2 gap-4">
                  {taskSummaries
                    .filter(task => task.imageUrl)
                    .map((task, index) => (
                      <div key={index} className="space-y-1">
                        <img
                          src={task.imageUrl}
                          alt={task.taskText}
                          className="w-full h-40 object-cover rounded-lg"
                        />
                        <p className="text-xs text-gray-500">{task.taskText}</p>
                      </div>
                    ))}
                </div>
              </div>
            )}
          </div>
        </div>

        <div className="flex justify-between items-center">
          <p className="text-sm text-gray-500">
            This will send a notification and reset the checklist.
          </p>
          <div className="flex gap-3">
            <button
              onClick={onClose}
              className="px-4 py-2 text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200"
              disabled={isSending}
            >
              Cancel
            </button>
            <button
              onClick={handleSendAndReset}
              disabled={isSending || isSuccess || !cleaner}
              className="px-4 py-2 text-white bg-blue-500 rounded-lg hover:bg-blue-600 disabled:opacity-50 flex items-center gap-2"
            >
              {isSending ? (
                <RefreshCw className="animate-spin" size={20} />
              ) : isSuccess ? (
                'Sent!'
              ) : !cleaner ? (
                'No cleaner assigned'
              ) : (
                <>
                  <Send size={20} />
                  Send & Reset
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}