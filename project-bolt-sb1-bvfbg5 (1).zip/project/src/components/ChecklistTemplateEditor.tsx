import React, { useState } from 'react';
import { PlusCircle, Trash2, GripVertical } from 'lucide-react';
import { DragDropContext, Droppable, Draggable, DropResult } from '@hello-pangea/dnd';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { Task } from '../types/task';
import { DEFAULT_TASKS } from '../utils/taskUtils';

export function ChecklistTemplateEditor() {
  const [templateTasks, setTemplateTasks] = useLocalStorage<Task[]>(
    'checklist-template',
    DEFAULT_TASKS
  );
  const [newTask, setNewTask] = useState('');

  const handleAddTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (newTask.trim()) {
      setTemplateTasks([
        ...templateTasks,
        { id: Math.random().toString(36).substr(2, 9), text: newTask.trim(), rating: 0, details: {} }
      ]);
      setNewTask('');
    }
  };

  const handleDeleteTask = (id: string) => {
    setTemplateTasks(templateTasks.filter(task => task.id !== id));
  };

  const handleDragEnd = (result: DropResult) => {
    if (!result.destination) return;

    const reorderedTasks = Array.from(templateTasks);
    const [movedTask] = reorderedTasks.splice(result.source.index, 1);
    reorderedTasks.splice(result.destination.index, 0, movedTask);

    setTemplateTasks(reorderedTasks);
  };

  return (
    <div className="space-y-4">
      <form onSubmit={handleAddTask} className="flex gap-2">
        <input
          type="text"
          value={newTask}
          onChange={(e) => setNewTask(e.target.value)}
          placeholder="Add new template task..."
          className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
        <button
          type="submit"
          disabled={!newTask.trim()}
          className="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500 flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <PlusCircle size={20} />
          Add Task
        </button>
      </form>

      <DragDropContext onDragEnd={handleDragEnd}>
        <Droppable droppableId="template-tasks">
          {(provided) => (
            <div
              {...provided.droppableProps}
              ref={provided.innerRef}
              className="space-y-2"
            >
              {templateTasks.map((task, index) => (
                <Draggable 
                  key={task.id} 
                  draggableId={task.id} 
                  index={index}
                >
                  {(provided, snapshot) => (
                    <div
                      ref={provided.innerRef}
                      {...provided.draggableProps}
                      className={`flex items-center gap-3 bg-gray-50 p-3 rounded-lg group ${
                        snapshot.isDragging ? 'shadow-lg ring-2 ring-blue-500' : ''
                      }`}
                    >
                      <div
                        {...provided.dragHandleProps}
                        className="text-gray-400 cursor-move hover:text-gray-600 transition-colors"
                      >
                        <GripVertical size={20} />
                      </div>
                      <span className="flex-1 text-gray-700">{task.text}</span>
                      <button
                        onClick={() => handleDeleteTask(task.id)}
                        className="text-red-500 hover:text-red-600 opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <Trash2 size={20} />
                      </button>
                    </div>
                  )}
                </Draggable>
              ))}
              {provided.placeholder}
            </div>
          )}
        </Droppable>
      </DragDropContext>
    </div>
  );
}