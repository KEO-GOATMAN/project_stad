import React, { useState } from 'react';
import { Trash2, AlertTriangle, Image as ImageIcon } from 'lucide-react';
import { Task, TaskDetail } from '../types/task';
import { TaskDetails } from './TaskDetails';
import { StarRating } from './StarRating';
import { shouldShowWarning } from '../utils/ratingUtils';

interface TaskItemProps {
  task: Task;
  onRate: (id: string, rating: number) => void;
  onDelete: (id: string) => void;
  onUpdateDetails: (id: string, details: TaskDetail) => void;
}

export function TaskItem({ task, onRate, onDelete, onUpdateDetails }: TaskItemProps) {
  const [isDetailsOpen, setIsDetailsOpen] = useState(false);
  const needsAttention = shouldShowWarning(task.rating);

  return (
    <div className={`bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors ${
      needsAttention ? 'border-l-4 border-yellow-400' : ''
    }`}>
      <div className="flex items-center justify-between p-4">
        <div className="flex items-center gap-4">
          <StarRating rating={task.rating} onRate={(rating) => onRate(task.id, rating)} />
          <span className="text-lg text-gray-700 flex items-center gap-2">
            {task.text}
            {task.details.imageUrl && (
              <ImageIcon size={16} className="text-blue-500" />
            )}
            {needsAttention && (
              <AlertTriangle size={20} className="text-yellow-500" />
            )}
          </span>
        </div>
        <button
          onClick={() => onDelete(task.id)}
          className="text-red-500 hover:text-red-600 focus:outline-none"
        >
          <Trash2 size={20} />
        </button>
      </div>
      
      <TaskDetails
        isOpen={isDetailsOpen}
        details={task.details}
        onUpdate={(details) => onUpdateDetails(task.id, details)}
        onToggle={() => setIsDetailsOpen(!isDetailsOpen)}
        rating={task.rating}
      />
    </div>
  );
}