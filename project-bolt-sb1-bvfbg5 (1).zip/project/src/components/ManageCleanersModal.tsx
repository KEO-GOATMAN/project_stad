import React, { useState, useMemo } from 'react';
import { Users, X, Plus, Trash2 } from 'lucide-react';
import { Cleaner } from '../types/cleaner';
import { Housing } from '../types/housing';
import { generateCleanerId } from '../utils/cleanerUtils';
import { SearchBar } from './SearchBar';

interface ManageCleanersModalProps {
  cleaners: Cleaner[];
  housingList: Housing[];
  onClose: () => void;
  onUpdate: (cleaners: Cleaner[]) => void;
}

export function ManageCleanersModal({ 
  cleaners, 
  housingList, 
  onClose, 
  onUpdate 
}: ManageCleanersModalProps) {
  const [newCleaner, setNewCleaner] = useState({
    name: '',
    username: '',
    password: '',
    email: ''
  });
  const [searchQuery, setSearchQuery] = useState('');

  const filteredHousingList = useMemo(() => {
    const query = searchQuery.toLowerCase();
    return housingList.filter(housing => 
      housing.name.toLowerCase().includes(query) ||
      housing.brf.toLowerCase().includes(query) ||
      housing.address.toLowerCase().includes(query)
    );
  }, [housingList, searchQuery]);

  const handleAddCleaner = () => {
    if (newCleaner.name && newCleaner.username && newCleaner.password && newCleaner.email) {
      const cleaner: Cleaner = {
        id: generateCleanerId(),
        name: newCleaner.name,
        username: newCleaner.username,
        password: newCleaner.password,
        email: newCleaner.email,
        assignedBrfs: []
      };
      onUpdate([...cleaners, cleaner]);
      setNewCleaner({ name: '', username: '', password: '', email: '' });
    }
  };

  const handleDeleteCleaner = (id: string) => {
    onUpdate(cleaners.filter(c => c.id !== id));
  };

  const toggleBrfAssignment = (cleanerId: string, brfId: string) => {
    onUpdate(cleaners.map(cleaner => {
      if (cleaner.id === cleanerId) {
        const assignedBrfs = cleaner.assignedBrfs.includes(brfId)
          ? cleaner.assignedBrfs.filter(id => id !== brfId)
          : [...cleaner.assignedBrfs, brfId];
        return { ...cleaner, assignedBrfs };
      }
      return cleaner;
    }));
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div className="bg-white rounded-lg shadow-xl p-6 w-full max-w-4xl mx-4 max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center mb-6">
          <div className="flex items-center gap-3">
            <Users className="h-6 w-6 text-blue-500" />
            <h2 className="text-2xl font-bold text-gray-800">Manage Cleaners</h2>
          </div>
          <button
            onClick={onClose}
            className="text-gray-500 hover:text-gray-700"
          >
            <X size={24} />
          </button>
        </div>

        <div className="space-y-6">
          <div className="bg-gray-50 p-4 rounded-lg">
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Add New Cleaner</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <input
                type="text"
                placeholder="Name"
                value={newCleaner.name}
                onChange={(e) => setNewCleaner(prev => ({ ...prev, name: e.target.value }))}
                className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <input
                type="text"
                placeholder="Username"
                value={newCleaner.username}
                onChange={(e) => setNewCleaner(prev => ({ ...prev, username: e.target.value }))}
                className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <input
                type="password"
                placeholder="Password"
                value={newCleaner.password}
                onChange={(e) => setNewCleaner(prev => ({ ...prev, password: e.target.value }))}
                className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
              <input
                type="email"
                placeholder="Email"
                value={newCleaner.email}
                onChange={(e) => setNewCleaner(prev => ({ ...prev, email: e.target.value }))}
                className="px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <button
              onClick={handleAddCleaner}
              disabled={!newCleaner.name || !newCleaner.username || !newCleaner.password || !newCleaner.email}
              className="mt-4 bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2"
            >
              <Plus size={20} />
              Add Cleaner
            </button>
          </div>

          <div className="space-y-4">
            {cleaners.map(cleaner => (
              <div key={cleaner.id} className="bg-gray-50 p-4 rounded-lg">
                <div className="flex justify-between items-center mb-4">
                  <div>
                    <h4 className="text-lg font-semibold text-gray-800">{cleaner.name}</h4>
                    <p className="text-sm text-gray-600">Username: {cleaner.username}</p>
                    <p className="text-sm text-gray-600">Email: {cleaner.email}</p>
                  </div>
                  <button
                    onClick={() => handleDeleteCleaner(cleaner.id)}
                    className="text-red-500 hover:text-red-600 p-2 hover:bg-red-50 rounded-full"
                  >
                    <Trash2 size={20} />
                  </button>
                </div>

                <div className="space-y-2">
                  <div className="flex items-center justify-between mb-2">
                    <h5 className="font-medium text-gray-700">Assigned BRFs:</h5>
                    <div className="w-64">
                      <SearchBar
                        value={searchQuery}
                        onChange={setSearchQuery}
                        placeholder="Search BRFs..."
                      />
                    </div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                    {filteredHousingList.map(housing => (
                      <label
                        key={housing.id}
                        className="flex items-center gap-2 p-2 bg-white rounded-lg cursor-pointer hover:bg-gray-100"
                      >
                        <input
                          type="checkbox"
                          checked={cleaner.assignedBrfs.includes(housing.id)}
                          onChange={() => toggleBrfAssignment(cleaner.id, housing.id)}
                          className="rounded text-blue-500 focus:ring-blue-500"
                        />
                        <div className="flex-1">
                          <div className="font-medium">{housing.name}</div>
                          <div className="text-sm text-gray-500">{housing.brf}</div>
                        </div>
                      </label>
                    ))}
                  </div>
                  {filteredHousingList.length === 0 && (
                    <p className="text-center text-gray-500 py-4">
                      No BRFs found matching your search.
                    </p>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}