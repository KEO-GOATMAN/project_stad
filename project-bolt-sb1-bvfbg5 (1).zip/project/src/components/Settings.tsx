import React from 'react';
import { useNavigate } from 'react-router-dom';
import { ClipboardList, ArrowLeft } from 'lucide-react';
import { Header } from './Header';
import { ChecklistTemplateEditor } from './ChecklistTemplateEditor';

export function Settings() {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-gray-100">
      <Header />
      <div className="max-w-3xl mx-auto p-6">
        <div className="bg-white rounded-lg shadow-lg p-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <ClipboardList className="h-8 w-8 text-blue-500" />
              <h1 className="text-3xl font-bold text-gray-800">Settings</h1>
            </div>
            <button
              onClick={() => navigate(-1)}
              className="p-2 text-gray-600 hover:text-gray-800 hover:bg-gray-100 rounded-full transition-colors"
              title="Go Back"
            >
              <ArrowLeft size={24} />
            </button>
          </div>

          <div className="space-y-6">
            <div className="border-b border-gray-200 pb-6">
              <h2 className="text-xl font-semibold text-gray-800 mb-4">
                Checklist Template
              </h2>
              <p className="text-gray-600 mb-4">
                Edit the default checklist template that will be used for all new BRFs.
              </p>
              <ChecklistTemplateEditor />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}