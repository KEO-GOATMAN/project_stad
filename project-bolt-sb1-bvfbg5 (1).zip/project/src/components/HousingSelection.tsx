import React, { useState, useMemo } from 'react';
import { useNavigate } from 'react-router-dom';
import { Building2, MapPin, Calendar, PlusCircle, Trash2, Users } from 'lucide-react';
import { MOCK_HOUSING_LIST } from '../utils/housingUtils';
import { MOCK_CLEANERS } from '../utils/cleanerUtils';
import { Header } from './Header';
import { AddHousingModal } from './AddHousingModal';
import { DeleteHousingModal } from './DeleteHousingModal';
import { ManageCleanersModal } from './ManageCleanersModal';
import { SearchBar } from './SearchBar';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { Housing } from '../types/housing';
import { Cleaner } from '../types/cleaner';
import { useAuth } from '../contexts/AuthContext';

export function HousingSelection() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [isManageCleanersOpen, setIsManageCleanersOpen] = useState(false);
  const [housingToDelete, setHousingToDelete] = useState<Housing | null>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [housingList, setHousingList] = useLocalStorage<Housing[]>(
    'housing-list',
    MOCK_HOUSING_LIST
  );
  const [cleaners, setCleaners] = useLocalStorage<Cleaner[]>(
    'cleaners',
    MOCK_CLEANERS
  );

  const filteredHousingList = useMemo(() => {
    const query = searchQuery.toLowerCase();
    let filtered = housingList.filter(housing => 
      housing.name.toLowerCase().includes(query) ||
      housing.brf.toLowerCase().includes(query) ||
      housing.address.toLowerCase().includes(query) ||
      housing.cleanerName.toLowerCase().includes(query) ||
      housing.cleaningDay.toLowerCase().includes(query)
    );

    // If user is a cleaner, only show assigned BRFs
    if (user?.role !== 'admin') {
      const cleaner = cleaners.find(c => c.username === user?.username);
      if (cleaner) {
        filtered = filtered.filter(housing => 
          cleaner.assignedBrfs.includes(housing.id)
        );
      }
    }

    return filtered;
  }, [housingList, searchQuery, user, cleaners]);

  const handleAddHousing = (newHousing: Housing) => {
    setHousingList([...housingList, newHousing]);
  };

  const handleDeleteHousing = (housing: Housing, e: React.MouseEvent) => {
    e.stopPropagation();
    setHousingToDelete(housing);
  };

  const confirmDelete = () => {
    if (housingToDelete) {
      setHousingList(housingList.filter(h => h.id !== housingToDelete.id));
      // Remove BRF from cleaner assignments
      setCleaners(cleaners.map(cleaner => ({
        ...cleaner,
        assignedBrfs: cleaner.assignedBrfs.filter(id => id !== housingToDelete.id)
      })));
      localStorage.removeItem(`housing-${housingToDelete.id}`);
      localStorage.removeItem(`cleaning-tasks-${housingToDelete.id}`);
      setHousingToDelete(null);
    }
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <Header />
      <div className="max-w-4xl mx-auto p-6">
        <div className="bg-white rounded-lg shadow-lg p-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <Building2 className="h-8 w-8 text-blue-500" />
              <h1 className="text-3xl font-bold text-gray-800">
                Select Bostadsrättsförening
              </h1>
            </div>
            {user?.role === 'admin' && (
              <div className="flex gap-2">
                <button
                  onClick={() => setIsManageCleanersOpen(true)}
                  className="bg-green-500 text-white px-4 py-2 rounded-lg hover:bg-green-600 focus:outline-none focus:ring-2 focus:ring-green-500 flex items-center gap-2"
                >
                  <Users size={20} />
                  Manage Cleaners
                </button>
                <button
                  onClick={() => setIsAddModalOpen(true)}
                  className="bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500 flex items-center gap-2"
                >
                  <PlusCircle size={20} />
                  Add New BRF
                </button>
              </div>
            )}
          </div>

          <div className="mb-6">
            <SearchBar
              value={searchQuery}
              onChange={setSearchQuery}
              placeholder="Search by name, address, cleaner..."
            />
          </div>

          {filteredHousingList.length === 0 ? (
            <div className="text-center py-8">
              <p className="text-gray-500">No BRFs found matching your search.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4">
              {filteredHousingList.map((housing) => (
                <div
                  key={housing.id}
                  className="group relative bg-gray-50 rounded-lg p-4 hover:bg-gray-100 transition-colors"
                >
                  <button
                    onClick={() => navigate(`/dashboard/${housing.id}`)}
                    className="w-full text-left"
                  >
                    <div className="flex gap-4">
                      {housing.imageUrl && (
                        <div className="w-32 h-32 overflow-hidden rounded-lg flex-shrink-0">
                          <img
                            src={housing.imageUrl}
                            alt={housing.name}
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                          />
                        </div>
                      )}
                      <div className="space-y-2">
                        <h3 className="text-lg font-semibold text-gray-800">
                          {housing.name}
                        </h3>
                        <div className="space-y-1 text-sm text-gray-600">
                          <div className="flex items-center gap-2">
                            <Building2 size={16} className="text-blue-500" />
                            <span>{housing.brf}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <MapPin size={16} className="text-blue-500" />
                            <span>{housing.address}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <Calendar size={16} className="text-blue-500" />
                            <span>{housing.cleaningDay}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </button>
                  {user?.role === 'admin' && (
                    <button
                      onClick={(e) => handleDeleteHousing(housing, e)}
                      className="absolute top-2 right-2 p-2 text-gray-400 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity rounded-full hover:bg-red-50"
                      title="Delete BRF"
                    >
                      <Trash2 size={20} />
                    </button>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {isAddModalOpen && (
        <AddHousingModal
          onClose={() => setIsAddModalOpen(false)}
          onAdd={handleAddHousing}
        />
      )}

      {isManageCleanersOpen && (
        <ManageCleanersModal
          cleaners={cleaners}
          housingList={housingList}
          onClose={() => setIsManageCleanersOpen(false)}
          onUpdate={setCleaners}
        />
      )}

      {housingToDelete && (
        <DeleteHousingModal
          housingName={housingToDelete.name}
          onConfirm={confirmDelete}
          onClose={() => setHousingToDelete(null)}
        />
      )}
    </div>
  );
}