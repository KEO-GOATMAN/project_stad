import React from 'react';
import { LogOut, Settings } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';

export function Header() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  return (
    <header className="bg-white shadow-sm">
      <div className="max-w-3xl mx-auto px-6 py-4 flex justify-between items-center">
        <div className="flex items-center gap-4">
          <h2 className="text-lg font-semibold text-gray-700">
            Welcome, {user?.username}
          </h2>
          <span className="px-2 py-1 bg-blue-100 text-blue-800 text-sm rounded-full">
            {user?.role}
          </span>
        </div>
        <div className="flex items-center gap-4">
          {user?.role === 'admin' && (
            <button
              onClick={() => navigate('/settings')}
              className="text-gray-600 hover:text-gray-800 flex items-center gap-2"
            >
              <Settings size={20} />
              <span>Settings</span>
            </button>
          )}
          <button
            onClick={logout}
            className="text-gray-600 hover:text-gray-800 flex items-center gap-2"
          >
            <LogOut size={20} />
            <span>Logout</span>
          </button>
        </div>
      </div>
    </header>
  );
}