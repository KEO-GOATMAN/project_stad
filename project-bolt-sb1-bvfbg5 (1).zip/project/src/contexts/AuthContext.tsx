import React, { createContext, useContext, useState } from 'react';
import { User, AuthContextType } from '../types/auth';
import { useLocalStorage } from '../hooks/useLocalStorage';
import { Cleaner } from '../types/cleaner';

const AuthContext = createContext<AuthContextType | null>(null);

const MOCK_USERS = {
  'Niklas': { password: 'Niklas123', role: 'admin' as const },
};

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(() => {
    const savedUser = localStorage.getItem('user');
    return savedUser ? JSON.parse(savedUser) : null;
  });

  const [cleaners] = useLocalStorage<Cleaner[]>('cleaners', []);

  const login = async (username: string, password: string) => {
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 500));

    // Check admin users first
    const adminUser = MOCK_USERS[username as keyof typeof MOCK_USERS];
    if (adminUser && adminUser.password === password) {
      const newUser = { username, role: adminUser.role };
      setUser(newUser);
      localStorage.setItem('user', JSON.stringify(newUser));
      return;
    }

    // Check cleaners from localStorage
    const cleaner = cleaners.find(c => 
      c.username === username && c.password === password
    );

    if (cleaner) {
      const newUser = { username, role: 'cleaner' as const };
      setUser(newUser);
      localStorage.setItem('user', JSON.stringify(newUser));
      return;
    }

    throw new Error('Invalid credentials');
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('user');
  };

  return (
    <AuthContext.Provider value={{ user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}