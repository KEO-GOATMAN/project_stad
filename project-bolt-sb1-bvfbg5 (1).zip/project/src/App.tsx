import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import { LoginPage } from './components/LoginPage';
import { ProtectedRoute } from './components/ProtectedRoute';
import { HousingSelection } from './components/HousingSelection';
import { Dashboard } from './components/Dashboard';
import { Settings } from './components/Settings';

export default function App() {
  return (
    <AuthProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/login" element={<LoginPage />} />
          <Route
            path="/housing"
            element={
              <ProtectedRoute>
                <HousingSelection />
              </ProtectedRoute>
            }
          />
          <Route
            path="/dashboard/:housingId"
            element={
              <ProtectedRoute>
                <Dashboard />
              </ProtectedRoute>
            }
          />
          <Route
            path="/settings"
            element={
              <ProtectedRoute>
                <Settings />
              </ProtectedRoute>
            }
          />
          <Route path="/" element={<Navigate to="/housing" replace />} />
        </Routes>
      </BrowserRouter>
    </AuthProvider>
  );
}