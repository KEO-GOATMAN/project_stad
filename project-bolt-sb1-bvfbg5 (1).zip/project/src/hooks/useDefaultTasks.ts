import { useLocalStorage } from './useLocalStorage';
import { Task } from '../types/task';
import { DEFAULT_TASKS } from '../utils/taskUtils';

export function useDefaultTasks() {
  const [templateTasks] = useLocalStorage<Task[]>('checklist-template', DEFAULT_TASKS);
  
  const getInitialTasks = () => {
    return templateTasks.map(task => ({
      ...task,
      id: Math.random().toString(36).substr(2, 9),
      rating: 0,
      details: {}
    }));
  };

  return { getInitialTasks };
}