export interface Cleaner {
  id: string;
  name: string;
  username: string;
  password: string;
  email: string;
  assignedBrfs: string[];
}