export interface Housing {
  id: string;
  name: string;
  brf: string;
  address: string;
  code: string;
  cleaningRoom: string;
  cleanerName: string;
  cleaningDay: string;
}