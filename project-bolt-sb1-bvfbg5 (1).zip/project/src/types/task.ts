export interface TaskDetail {
  comment?: string;
  imageUrl?: string;
}

export interface Task {
  id: string;
  text: string;
  rating: number;
  details: TaskDetail;
}

export interface TaskSection {
  id: string;
  title: string;
  tasks: Task[];
}