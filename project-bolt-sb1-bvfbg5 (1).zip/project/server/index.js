import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import nodemailer from 'nodemailer';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import { open } from 'sqlite';
import sqlite3 from 'sqlite3';

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

// Email configuration
const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_APP_PASSWORD
  }
});

// Database setup
let db;
async function setupDatabase() {
  db = await open({
    filename: 'database.sqlite',
    driver: sqlite3.Database
  });

  await db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      name TEXT,
      username TEXT UNIQUE,
      password TEXT,
      email TEXT,
      role TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS housing (
      id TEXT PRIMARY KEY,
      name TEXT,
      brf TEXT,
      address TEXT,
      code TEXT,
      cleaning_room TEXT,
      cleaner_name TEXT,
      cleaning_day TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );

    CREATE TABLE IF NOT EXISTS cleaner_assignments (
      cleaner_id TEXT,
      housing_id TEXT,
      FOREIGN KEY(cleaner_id) REFERENCES users(id),
      FOREIGN KEY(housing_id) REFERENCES housing(id),
      PRIMARY KEY(cleaner_id, housing_id)
    );
  `);

  // Insert default admin if not exists
  const adminExists = await db.get('SELECT * FROM users WHERE username = ?', ['Niklas']);
  if (!adminExists) {
    const hashedPassword = await bcrypt.hash('Niklas123', 10);
    await db.run(
      'INSERT INTO users (id, name, username, password, email, role) VALUES (?, ?, ?, ?, ?, ?)',
      ['admin1', 'Niklas', 'Niklas', hashedPassword, 'admin@example.com', 'admin']
    );
  }
}

// Authentication middleware
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) return res.sendStatus(401);

  jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
    if (err) return res.sendStatus(403);
    req.user = user;
    next();
  });
};

// Routes
app.post('/api/login', async (req, res) => {
  const { username, password } = req.body;

  try {
    const user = await db.get('SELECT * FROM users WHERE username = ?', [username]);
    
    if (!user) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const validPassword = await bcrypt.compare(password, user.password);
    if (!validPassword) {
      return res.status(401).json({ error: 'Invalid credentials' });
    }

    const token = jwt.sign(
      { id: user.id, username: user.username, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: '24h' }
    );

    res.json({ token, user: { username: user.username, role: user.role } });
  } catch (error) {
    console.error('Login error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/send-notification', authenticateToken, async (req, res) => {
  const { housing, taskSummaries, cleanerEmail } = req.body;

  try {
    // Generate email HTML with images
    let emailHtml = `
      <h2>Städrapport - ${housing.name}</h2>
      <p><strong>Brf:</strong> ${housing.brf}</p>
      <p><strong>Adress:</strong> ${housing.address}</p>
      <p><strong>Städare:</strong> ${housing.cleanerName}</p>
      <h3>Följande punkter kräver åtgärd:</h3>
    `;

    taskSummaries.forEach(task => {
      const stars = '★'.repeat(task.rating) + '☆'.repeat(5 - task.rating);
      emailHtml += `
        <div style="margin-bottom: 20px;">
          <h4>${task.taskText}</h4>
          <p>Betyg: ${stars}</p>
          ${task.comment ? `<p>Kommentar: ${task.comment}</p>` : ''}
          ${task.imageUrl ? `<img src="${task.imageUrl}" style="max-width: 300px; margin-top: 10px;">` : ''}
        </div>
      `;
    });

    await transporter.sendMail({
      from: process.env.EMAIL_USER,
      to: cleanerEmail,
      subject: `Städrapport - ${housing.name}`,
      html: emailHtml
    });

    res.json({ message: 'Notification sent successfully' });
  } catch (error) {
    console.error('Email error:', error);
    res.status(500).json({ error: 'Failed to send notification' });
  }
});

// Start server
const PORT = process.env.PORT || 3000;

setupDatabase().then(() => {
  app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
}).catch(error => {
  console.error('Failed to initialize database:', error);
  process.exit(1);
});