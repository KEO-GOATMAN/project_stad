# Optimal Trappstädning

A cleaning management system for housing associations.

## Setup

1. Install dependencies:
```bash
npm install
```

2. Create a `.env` file with the following variables:
```
PORT=3000
JWT_SECRET=your-secret-key-here
EMAIL_USER=your-email@gmail.com
EMAIL_APP_PASSWORD=your-gmail-app-password
```

3. Start the development server:
```bash
npm run dev
```

4. Start the backend server:
```bash
npm run server
```

## Deployment

For 24/7 operation, deploy to a cloud provider:

1. Frontend: Deploy to Netlify or Vercel
2. Backend: Deploy to a VPS or cloud service (DigitalOcean, Heroku, etc.)

### Email Setup

1. Create a Gmail account for the application
2. Enable 2-factor authentication
3. Generate an App Password
4. Add the email and app password to the environment variables

## Features

- User authentication (admin/cleaner roles)
- Housing association management
- Cleaning task management
- Email notifications for poor ratings
- Image attachments in reports

## Security

- JWT-based authentication
- Encrypted passwords
- Secure email transmission
- Environment variable protection